#pragma once

#define EPSILON (1e-4f)
