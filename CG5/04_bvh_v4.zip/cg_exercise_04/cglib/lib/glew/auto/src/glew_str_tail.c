    }
    ret = (len == 0);
  }
  return ret;
}

#endif /* _WIN32 */
// CG_REVISION b30b521c442c9eeb92ce1af7012b38130e53efcd
