/// @ref simd
/// @file glm/simd/vector_relational.h

#pragma once

#if GLM_ARCH & GLM_ARCH_SSE2_BIT

#endif//GLM_ARCH & GLM_ARCH_SSE2_BIT
// CG_REVISION b30b521c442c9eeb92ce1af7012b38130e53efcd
