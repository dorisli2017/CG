/// @ref core
/// @file glm/packing.hpp

#pragma once

#include "detail/func_packing.hpp"
// CG_REVISION b30b521c442c9eeb92ce1af7012b38130e53efcd
