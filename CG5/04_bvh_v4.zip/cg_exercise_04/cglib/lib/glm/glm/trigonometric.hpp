/// @ref core
/// @file glm/trigonometric.hpp

#pragma once

#include "detail/func_trigonometric.hpp"
// CG_REVISION b30b521c442c9eeb92ce1af7012b38130e53efcd
