/// @ref core
/// @file glm/exponential.hpp

#pragma once

#include "detail/func_exponential.hpp"
// CG_REVISION b30b521c442c9eeb92ce1af7012b38130e53efcd
