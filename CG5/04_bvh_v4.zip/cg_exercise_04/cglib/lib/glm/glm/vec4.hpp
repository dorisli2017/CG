/// @ref core
/// @file glm/vec4.hpp

#pragma once

#include "detail/type_vec4.hpp"
// CG_REVISION b30b521c442c9eeb92ce1af7012b38130e53efcd
